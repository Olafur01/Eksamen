interface MedGodUtsikt {
    // Oppretter en metode som henter usiktsverdien til klassen 
    int hentUtsiktsVerdi();
}
