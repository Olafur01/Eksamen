class Kjerrevei extends Sti{

    Kjerrevei(int lengde, Kryss startpunkt, Kryss endepunkt) {
        super(lengde, startpunkt, endepunkt);
    }
    
}
