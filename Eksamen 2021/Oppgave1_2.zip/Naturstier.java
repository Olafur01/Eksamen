class Naturstier extends Sti{

    Naturstier(int lengde, Kryss startpunkt, Kryss endepunkt) {
        super(lengde, startpunkt, endepunkt);
    }
    
   
}
